//
// Created by Huarote on 1/10/2025.
//

#ifndef LAB04_2025_1_BIBLIOTECAENTEROS_HPP
#define LAB04_2025_1_BIBLIOTECAENTEROS_HPP
#include "Utils.hpp"

void* leeNum(ifstream &);
int clasificaNum(void*);
void imprimeNum(ofstream &, void*);

#endif //LAB04_2025_1_BIBLIOTECAENTEROS_HPP