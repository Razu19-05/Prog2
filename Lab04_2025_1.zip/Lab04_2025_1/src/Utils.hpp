//
// Created by Huarote on 1/10/2025.
//

#ifndef LAB04_2025_1_UTILS_HPP
#define LAB04_2025_1_UTILS_HPP

#include <iostream>
#include <iomanip>
#include <fstream>
#include <cstring>
#define MAX_LINEAS 200
enum LISTA {INICIO,FINAL};
enum NODO {DATO, SIGUIENTE};
enum REGISTRO{LICENCIA,PLACA,FECHA,INFRACCION,NOMBRE};
using namespace std;

#endif //LAB04_2025_1_UTILS_HPP