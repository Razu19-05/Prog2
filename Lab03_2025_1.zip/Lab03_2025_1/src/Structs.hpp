//
// Created by Huarote on 16/09/2025.
//

#ifndef LAB03_2025_1_STRUCTS_HPP
#define LAB03_2025_1_STRUCTS_HPP

struct Tabla {
    void* columnas;
    void* filas;
    int cant_columnas;
    int cant_filas;
    int capacidad_columnas;
    int capacidad_filas;
};

#endif //LAB03_2025_1_STRUCTS_HPP