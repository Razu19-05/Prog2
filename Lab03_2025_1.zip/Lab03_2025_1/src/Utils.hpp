//
// Created by Huarote on 16/09/2025.
//

#ifndef LAB03_2025_1_UTILS_HPP
#define LAB03_2025_1_UTILS_HPP

#include <iostream>
#include <iomanip>
#include <fstream>
#include <cstring>
#define INCREMENTO_COLUMNA 2
enum REG_FILA {CODIGO, DESCRIPCION, TIPO, VALOR};

using namespace std;

#endif //LAB03_2025_1_UTILS_HPP