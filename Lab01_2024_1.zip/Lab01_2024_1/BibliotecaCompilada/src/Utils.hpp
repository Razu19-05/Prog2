//
// Created by Huarote on 29/08/2025.
//

#ifndef FUENTESBIBLIOTECA_UTILS_HPP
#define FUENTESBIBLIOTECA_UTILS_HPP

#include <iostream>
#include <fstream>
#include <iomanip>
#include <cmath>
#include <cstring>
#define MAX_LINEAS 100

using namespace std;

#endif //FUENTESBIBLIOTECA_UTILS_HPP