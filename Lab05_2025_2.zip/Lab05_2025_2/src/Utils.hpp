

#ifndef LAB05_2025_2_UTILS_HPP
#define LAB05_2025_2_UTILS_HPP

#include <iostream>
#include <iomanip>
#include <fstream>
#include <cstring>
#define INCREMENTO 5
enum LISTA_REAL {INICIO};
enum NODO {DATO, SIGUIENTE};
enum REGISTRO_CONDUCTOR {LICENCIA, NOMBRE, ARR, LISTA};
enum REGISTRO_INFRACCIONES{LICENCIA1, PLACA, FECHA, TIPO};

using namespace std;

#endif //LAB05_2025_2_UTILS_HPP